# PilotSeries Backend

**PilotSeries** es una plataforma FullStack para gestionar, descubrir y puntuar series, con usuarios, roles y control administrativo. Este repositorio contiene el backend construido con **Node.js, Express y MongoDB**, con soporte para subida de imágenes a **Cloudinary** y autenticación JWT.

---

## 🚀 Tecnologías Principales

- Node.js / Express
- MongoDB / Mongoose
- JWT (JSON Web Tokens)
- Multer + Cloudinary (subida y gestión de imágenes)
- BcryptJS (hash de contraseñas)
- dotenv (variables de entorno)
- CORS seguro

---

## 📦 Instalación y Puesta en Marcha

1. **Clona el repo:**

   ```bash
   git clone [URL_DE_TU_REPO]
   cd [NOMBRE_DEL_DIRECTORIO]
   ```

2. **Instala dependencias:**

   ```bash
   npm install
   ```

3. **Configura tu `.env`:**  
   Crea un archivo `.env` en la raíz con:

   ```
   MONGO_URI=mongodb+srv://<user>:<password>@cluster.mongodb.net/pilotseries
   JWT_SECRET=EscribeUnaClaveSegura
   CLOUDINARY_CLOUD_NAME=XXXX
   CLOUDINARY_API_KEY=XXXX
   CLOUDINARY_API_SECRET=XXXX
   ORIGINS=http://localhost:5173,https://tudominiofront.com
   ```

4. **Carga los datos iniciales (seeds):**

   ```bash
   node src/scripts/index.seed.js
   ```

   Esto poblará la BBDD con series, usuarios y reviews de ejemplo.

5. **Levanta el servidor:**
   ```bash
   npm run dev
   ```
   Por defecto corre en el puerto `3001`.  
   Accede a los endpoints en `http://localhost:3001/api/...`

---

## 👩‍💻 Rutas principales de la API

> Todas las rutas devuelven y esperan **JSON**.  
> Algunas requieren **token JWT** (añádelo como header `Authorization: Bearer <token>`).

### Auth

| Ruta                 | Método | Body / Params                              | Descripción                                                        |
| -------------------- | ------ | ------------------------------------------ | ------------------------------------------------------------------ |
| `/api/auth/register` | POST   | nombre, email, password, imagen (opcional) | Registro de usuario (imagen se manda como archivo, tipo form-data) |
| `/api/auth/login`    | POST   | email, password                            | Login, devuelve JWT y datos del usuario                            |

---

### Usuarios

| Ruta                      | Método | Body / Params                              | Descripción                   |
| ------------------------- | ------ | ------------------------------------------ | ----------------------------- |
| `/api/usuarios/me`        | GET    | -                                          | Obtener perfil propio (token) |
| `/api/usuarios/me`        | PUT    | nombre, email, password, imagen (opcional) | Editar perfil propio          |
| `/api/usuarios/`          | GET    | -                                          | (Admin) Listar usuarios       |
| `/api/usuarios/:id/ban`   | PUT    | -                                          | (Admin) Banear usuario        |
| `/api/usuarios/:id/unban` | PUT    | -                                          | (Admin) Desbanear usuario     |

---

### Series

| Ruta                         | Método | Body / Params                                                            | Descripción              |
| ---------------------------- | ------ | ------------------------------------------------------------------------ | ------------------------ |
| `/api/series`                | GET    | -                                                                        | Listar todas las series  |
| `/api/series/:id`            | GET    | -                                                                        | Detalle de una serie     |
| `/api/series/`               | POST   | (Admin) serie, descripcion, urlImagen/plataforma/tipo, imagen (opcional) | Crear serie              |
| `/api/series/:id`            | PUT    | (Admin) campos editables, imagen (opcional)                              | Editar serie             |
| `/api/series/:id`            | DELETE | (Admin)                                                                  | Eliminar serie           |
| `/api/series/:id/follow`     | POST   | -                                                                        | Seguir una serie         |
| `/api/series/:id/unfollow`   | POST   | -                                                                        | Dejar de seguir          |
| `/api/series/:id/favorite`   | POST   | -                                                                        | Marcar como favorita     |
| `/api/series/:id/unfavorite` | POST   | -                                                                        | Quitar de favoritas      |
| `/api/series/:id/finish`     | POST   | -                                                                        | Marcar como finalizada   |
| `/api/series/:id/unfinish`   | POST   | -                                                                        | Quitar de finalizadas    |
| `/api/series/:id/rate`       | POST   | rating                                                                   | Valorar una serie (0-10) |

---

### Reviews

| Ruta                          | Método | Body / Params                     | Descripción           |
| ----------------------------- | ------ | --------------------------------- | --------------------- |
| `/api/reviews/serie/:serieId` | GET    | -                                 | Reviews de una serie  |
| `/api/reviews/user/:userId`   | GET    | -                                 | Reviews de un usuario |
| `/api/reviews/`               | POST   | serie, comentario, rating (token) | Crear review          |
| `/api/reviews/:id`            | DELETE | - (Admin)                         | Eliminar review       |

---

## 👤 Roles y Seguridad

- Usuarios con rol **admin** pueden gestionar usuarios, banear, crear y editar series.
- Contraseñas seguras (mínimo 8 caracteres, mayúsculas, número y símbolo).
- Imágenes de perfil y portadas subidas a Cloudinary.
- Las rutas protegidas requieren token JWT válido.
- Usuarios baneados no pueden loguearse.

---

## 🌩️ Subida de imágenes

- **Perfil:** Al registrarte o editar perfil, puedes enviar una imagen como archivo (`imagen`) usando `multipart/form-data`.
- **Series:** Admin puede subir portada de serie al crearla/editarla (`urlImagen` en el form).

---

## 🧪 Usuarios de prueba

- **Admin:**  
  `email: admin@pilotseries.com`  
  `password: Password123!`
- **Usuario normal:**  
  `email: user1@pilotseries.com`  
  `password: Password123!`

---

## 📑 Variables de entorno requeridas

- `MONGO_URI`
- `JWT_SECRET`
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`
- `ORIGINS` (ejemplo: `http://localhost:5173,https://tudominiofront.com`)

---

## 🚀 Despliegue

- Recuerda añadir el dominio del frontend a `ORIGINS` en `.env`.
- El backend puede ser desplegado en Render, Railway, Heroku, etc.
- El frontend debe apuntar a la URL del backend `/api/` en producción.

---

## 📣 Autor

**Àrian Castro - theycallmearian**  
Proyecto final FullStack para Rock The Code. 2025.

---
